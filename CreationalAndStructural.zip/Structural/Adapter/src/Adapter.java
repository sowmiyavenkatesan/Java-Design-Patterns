public class Adapter implements Logger{

    private final OldLogger oldLogger;

    public Adapter(OldLogger oldLogger)
    {
        this.oldLogger = oldLogger;
    }

    @Override
    public void logInfo(String message)
    {
        this.oldLogger.oldInfoLogger(message);
    }

    @Override
    public void logError(String message)
    {
        this.oldLogger.oldErrorLogger(message);
    }
}
