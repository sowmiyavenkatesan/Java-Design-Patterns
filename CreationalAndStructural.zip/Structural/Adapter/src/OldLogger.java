/**
 * Adaptee class which needs to implement the methods of
 * the target interface without modifying this class.
 */
public class OldLogger {
    public void oldInfoLogger(String message)
    {
        System.out.println("Logging info: " + message);
    }

    public void oldErrorLogger(String message)
    {
        System.out.println("Logging error: " + message);
    }
}