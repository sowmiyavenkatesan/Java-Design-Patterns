public class Main {
    public static void main(String[] args) {

        // Adapter pattern is used when you have a legacy/old interface which
        // needs to get adapter to a new target interface.

        // Target interface - Logger.
        // Adaptee (which needs to implement the target interface methods without making any changes in it).
        // Adapter which implements the target interface methods and making the
        // Adaptee class to use its existing methods there.


        Adapter adapter = new Adapter(new OldLogger());
        adapter.logInfo("Test Info message..");
        adapter.logError("Test Error message..");
    }
}