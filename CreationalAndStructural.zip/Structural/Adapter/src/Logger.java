/**
 * Target interface
 */
public interface Logger {
    void logInfo(String message);
    void logError(String errorMessage);
}
