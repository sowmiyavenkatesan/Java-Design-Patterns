public class Main {
    public static void main(String[] args) {
        // Let’s imagine you are building a media player app. This app needs
        // to play various media types like MP3, MP4, WAV, and so on.
        // You want the app to support multiple platforms (like Windows, Mac, Linux, Mobile).
        //Here's how the Bridge Pattern can be applied to decouple the "what"
        // the app does (playing media) from the "how" it does it
        // (the platform-specific implementation of playing the media).

        /**
         * Abstraction: The MediaPlayer class defines the high-level behavior like play().
         * Implementor: The MediaFormat interface defines the platform-specific way of playing different media files.
         * Bridge: The MediaPlayer delegates the playing task to the platform-specific MediaFormat object.
         */
        MediaFormat widowsMediaFormat = new WindowsPlayer();
        MediaFormat macMediaFormat = new MacPlayer();

        // Making MP3 to play on windows.
        MP3Player windowsMp3Player = new MP3Player(widowsMediaFormat);
        // Making MP3 to play on MAC.
        MP3Player macMp3Player = new MP3Player(macMediaFormat);

        windowsMp3Player.play();
        macMp3Player.play();

        MP4Player windowsMp4Player = new MP4Player(widowsMediaFormat);
        // Making MP4 to play on windows.
        windowsMp4Player.play();
    }
}