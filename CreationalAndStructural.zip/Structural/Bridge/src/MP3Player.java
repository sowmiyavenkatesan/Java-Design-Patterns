public class MP3Player extends MediaPlayer{

    public MP3Player(MediaFormat mediaFormat)
    {
        super(mediaFormat);
    }

    @Override
    public void play()
    {
        System.out.println("Playing MP3:");
        mediaFormat.playMedia("takitaki.mp3");
    }
}