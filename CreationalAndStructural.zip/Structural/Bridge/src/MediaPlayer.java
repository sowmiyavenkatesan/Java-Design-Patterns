public abstract class MediaPlayer {
    public MediaFormat mediaFormat;
    public MediaPlayer(MediaFormat mediaFormat)
    {
        this.mediaFormat = mediaFormat;
    }
    public abstract void play();
}