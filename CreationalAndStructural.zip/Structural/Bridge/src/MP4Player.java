public class MP4Player extends MediaPlayer{

    public MP4Player(MediaFormat mediaFormat) {
        super(mediaFormat);
    }

    @Override
    public void play()
    {
        System.out.println("MP4:");
        mediaFormat.playMedia("Harry Potter and the Chambers of Secrets");
    }
}