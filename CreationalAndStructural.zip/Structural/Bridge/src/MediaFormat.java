public interface MediaFormat {
    void playMedia(String fileName);
}
