public class MacPlayer implements MediaFormat {
    @Override
    public void playMedia(String fileName)
    {
        System.out.println("Playing " + fileName + " on mac");
    }
}