import java.util.ArrayList;
import java.util.List;

public class Folder implements FileSystem {

    List<File> fileList = new ArrayList<>();

    public void addFile(File file)
    {
        this.fileList.add(file);
    }

    @Override
    public void showDetails()
    {
        System.out.println("Showing folder details");
        this.fileList.forEach(file -> {
            file.showDetails();
        });
    }
}