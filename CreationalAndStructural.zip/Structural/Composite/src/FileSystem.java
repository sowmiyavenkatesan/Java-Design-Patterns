public interface FileSystem {
    void showDetails();
}
