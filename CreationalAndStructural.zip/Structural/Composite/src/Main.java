public class Main {
    public static void main(String[] args) {
        /**
         * Composite Design Pattern : The Composite Design Pattern is a structural pattern
         * that allows you to treat individual objects and compositions (groups) of objects
         * in a uniform way. It’s mainly used when you have a hierarchy of objects
         * (like a tree structure) and you want to treat both
         * individual objects and groups of objects the same way.
         */

        /**
         * How Does It Work in Java?
         * Component: This is an abstract class or interface that defines common methods
         * for both leaf (individual) and composite (group) objects.
         * This might include methods like add(), remove(), or display().
         *
         * Leaf: These are the individual objects (like a file).
         * They implement the methods from the Component class but don’t have children themselves.
         *
         * Composite: These are the objects that can contain other Component objects
         * (like folders). They also implement the same methods but can hold a collection
         * of Component objects (both leaves and composites).
         */
        File file1 = new File("file1.txt");
        File file2 = new File("file2.txt");

        Folder folder = new Folder();
        folder.addFile(file1);
        folder.addFile(file2);

        folder.showDetails();
    }
}