public class SugarDecorator extends CoffeeDecorator{

    public SugarDecorator(Coffee coffee)
    {
        super(coffee);
    }

    @Override
    public Long cost()
    {
        return this.coffee.cost() + 1L;
    }
}
