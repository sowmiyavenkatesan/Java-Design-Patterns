public class CoffeeDecorator implements Coffee {
    Coffee coffee;

    public CoffeeDecorator(Coffee coffee)
    {
        this.coffee = coffee;
    }

    @Override
    public Long cost()
    {
        return this.coffee.cost();
    }
}