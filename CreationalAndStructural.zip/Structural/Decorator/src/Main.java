public class Main {
    public static void main(String[] args) {

        Coffee simpleCoffee = new SimpleCoffee();
        Coffee whippingCreamDecorator = new WhippingCreamDecorator(simpleCoffee);
        System.out.println("SimpleCoffee + Whipping Cream = $5 + $2 = $" + whippingCreamDecorator.cost());
        Coffee sugarDecorator = new SugarDecorator(whippingCreamDecorator);
        System.out.println("SimpleCoffee + Whipping Cream + Sugar = $5 + $2 + $1 = $" + sugarDecorator.cost());
        Coffee simpleSugarDecorator = new SugarDecorator(simpleCoffee);
        System.out.println("SimpleCoffee + Sugar = $5 + $1 = $" + simpleSugarDecorator.cost());

    }
}