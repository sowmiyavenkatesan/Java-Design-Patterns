public class WhippingCreamDecorator extends CoffeeDecorator{

    public WhippingCreamDecorator(Coffee coffee)
    {
        super(coffee);
    }

    @Override
    public Long cost()
    {
        return coffee.cost() + 2L;
    }
}