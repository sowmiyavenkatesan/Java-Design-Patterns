public class SimpleCoffee implements Coffee {
    @Override
    public Long cost()
    {
        return 5L;
    }
}
