public interface Coffee {
    Long cost();
}