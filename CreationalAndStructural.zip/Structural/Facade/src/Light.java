public class Light {
    public void dim()
    {
        System.out.println("Lights Dimmed");
    }

    public void turnOn()
    {
        System.out.println("Lights turned on");
    }

    public void turnOff()
    {
        System.out.println("Lights turned off");
    }
}
