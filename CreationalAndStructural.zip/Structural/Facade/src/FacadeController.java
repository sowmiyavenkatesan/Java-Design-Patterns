public class FacadeController {
    private Light light;
    private Projector projector;
    private DVDPlayer dvdPlayer;

    public FacadeController(Light light,Projector projector,DVDPlayer dvdPlayer)
    {
        this.light = light;
        this.projector = projector;
        this.dvdPlayer = dvdPlayer;
    }

    public void watchMovie()
    {
        light.dim();
        projector.turnOn();
        dvdPlayer.turnOn();
        dvdPlayer.play();
    }

    public void stopMovie()
    {
        light.turnOn();
        projector.turnOff();
        dvdPlayer.turnOff();
    }
}
