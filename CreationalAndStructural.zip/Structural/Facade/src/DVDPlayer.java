public class DVDPlayer {
    public void turnOn()
    {
        System.out.println("DVD Player turned on..");
    }

    public void turnOff()
    {
        System.out.println("DVD Player turned off..");
    }

    public void play()
    {
        System.out.println("Playing movie..");
    }
}
