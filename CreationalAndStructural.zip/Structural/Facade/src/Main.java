public class Main {
    public static void main(String[] args) {
        Light light = new Light();
        Projector projector = new Projector();
        DVDPlayer dvdPlayer = new DVDPlayer();

        FacadeController facadeController = new FacadeController(light,projector,dvdPlayer);
        System.out.println("*********Executing Watch Movie Actions..*********");
        facadeController.watchMovie();
        System.out.println("*********Executing Stop Movie Actions..*********");
        facadeController.stopMovie();
    }
}