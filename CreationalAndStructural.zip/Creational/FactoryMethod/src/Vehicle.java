public interface Vehicle {
    void createVehicle();
}
