public class VehicleFactory {
    public Vehicle getVehicle(String type)
    {
        Vehicle vehicle = null;
        switch(type)
        {
            case "Car":
            {
                vehicle = new Car();
                break;
            }
            case "Bicyle":
            {
                vehicle = new Bicycle();
                break;
            }
        }
        return vehicle;
    }
}