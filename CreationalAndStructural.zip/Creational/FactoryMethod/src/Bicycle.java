public class Bicycle implements Vehicle{
    @Override
    public void createVehicle()
    {
        System.out.println("Creating bicycle..");
    }
}
