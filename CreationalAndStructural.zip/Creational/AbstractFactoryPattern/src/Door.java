public interface Door {
    void createDoor();
}
