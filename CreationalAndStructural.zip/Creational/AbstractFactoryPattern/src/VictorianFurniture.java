public class VictorianFurniture implements Furniture{
    @Override
    public void createFurniture()
    {
        System.out.println("Creating victorian furniture..");
        System.out.println("Created victorian furniture..");
    }
}
