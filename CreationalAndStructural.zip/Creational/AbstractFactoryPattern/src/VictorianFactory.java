public class VictorianFactory implements AbstractFactory{

    @Override
    public Door getDoor()
    {
        return new VictorianDoor();
    }

    @Override
    public Furniture getFurniture()
    {
        return new VictorianFurniture();
    }
}