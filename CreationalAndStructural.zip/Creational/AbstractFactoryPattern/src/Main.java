public class Main {
    public static void main(String[] args) {
        /**  Assume you want to generate different styles of door like
             victorian/modern and different types of furniture of the same styles.
             So, we can have modern and victorian factory which takes care of
             generating their respective styled door and furniture. These
             modern and victorian factories implements abstract factory which takes care
             of just generating the door and furniture. **/
        AbstractFactory factory = new ModernFactory();
        Door door = factory.getDoor();
        Furniture furniture = factory.getFurniture();
        door.createDoor();
        furniture.createFurniture();
    }
}