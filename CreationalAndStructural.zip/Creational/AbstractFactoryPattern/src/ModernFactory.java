public class ModernFactory implements AbstractFactory{

    @Override
    public Door getDoor()
    {
        return new ModernDoor();
    }

    @Override
    public Furniture getFurniture()
    {
        return new ModernFurniture();
    }
}