public interface Furniture {
    void createFurniture();
}
