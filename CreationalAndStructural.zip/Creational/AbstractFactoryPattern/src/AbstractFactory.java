public interface AbstractFactory {
    Door getDoor();
    Furniture getFurniture();
}