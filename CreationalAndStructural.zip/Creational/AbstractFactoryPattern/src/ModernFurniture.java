public class ModernFurniture implements Furniture{
    @Override
    public void createFurniture()
    {
        System.out.println("Creating modern furniture..");
        System.out.println("Created modern furniture..");
    }
}