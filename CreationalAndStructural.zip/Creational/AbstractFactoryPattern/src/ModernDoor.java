public class ModernDoor implements Door{

    @Override
    public void createDoor()
    {
        System.out.println("Creating modern door..");
        System.out.println("Created modern door..");
    }
}
