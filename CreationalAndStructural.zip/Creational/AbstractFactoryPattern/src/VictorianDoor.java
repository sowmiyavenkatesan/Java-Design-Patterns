public class VictorianDoor implements Door{
    @Override
    public void createDoor()
    {
        System.out.println("Creating victorian door..");
        System.out.println("Created victorian door..");
    }
}