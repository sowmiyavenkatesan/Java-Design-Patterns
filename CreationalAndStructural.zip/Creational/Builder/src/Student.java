public class Student {
    private final String name;
    private final Integer age;
    private final String designation;
    private final String company;

    private Student(StudentBuilder studentBuilder)
    {
        this.name = studentBuilder.name;
        this.age = studentBuilder.age;
        this.designation = studentBuilder.designation;
        this.company = studentBuilder.company;
    }

    @Override
    public String toString() {
        return "Name: " + name + "\nAge: " + age + "\nDesignation: " + designation + "\nCompany: " + company;
    }

    public String getName()
    {
        return this.name;
    }

    public Integer getAge()
    {
        return this.age;
    }

    public String getDesignation()
    {
        return this.designation;
    }

    public String getCompany()
    {
        return this.company;
    }

    public static class StudentBuilder {
        // Mandatory fields.
        private String name;
        private Integer age;

        // Non-Mandatory fields.
        private String designation;
        private String company;

        public StudentBuilder(String name,Integer age)
        {
            // Strictly making the constructor
            // to set the mandatory fields.
            this.name = name;
            this.age = age;
        }

        public StudentBuilder designation(String designation)
        {
            this.designation = designation;
            return this;
        }

        public StudentBuilder company(String company)
        {
            this.company = company;
            return this;
        }

        public Student build()
        {
            return new Student(this);
        }
    }
}