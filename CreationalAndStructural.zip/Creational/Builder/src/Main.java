public class Main {
    public static void main(String[] args) {

        Student student = new Student
                .StudentBuilder("Sowmiya",24) // If we want to set the mandatory fields then set it via constructor.
                .company("Paypal,Ex-Walmart")
                .designation("SDE-II")
                .build();

        System.out.println(student.toString());
    }
}